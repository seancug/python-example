from distutils.core import setup
setup(
    name         = 'nester',
    version      = '1.0.0',
    py_modules   = ['nester'],
    author       = 'sean',
    author_email = 'seancug@hotmail.com',
    url          = 'seancug@hotmail.com',
    description  = 'A simple printer of lister',
    )
