"""
Modules for graphical user interfaces (GUI)

* :mod:`~fatiando.gui.simple`: Simple GUIs using the interactive capabilities
  of :mod:`matplotlib`

----

"""
